#include<iostream>
#include<windows.h>
#include<MMsystem.h>
using namespace std;

void play(int n)
{

 switch(n)
{
	case 0:
		PlaySound(TEXT("m0.wav"),NULL,SND_SYNC);
		break;
	case 1:
		PlaySound(TEXT("m1.wav"),NULL,SND_SYNC);
		break;
	case 2:
		PlaySound(TEXT("m2.wav"),NULL,SND_SYNC);
		break;
	case 3:
		PlaySound(TEXT("m3.wav"),NULL,SND_SYNC);
		break;
	case 4:
		PlaySound(TEXT("m4.wav"),NULL,SND_SYNC);
		break;
	case 5:
		PlaySound(TEXT("m5.wav"),NULL,SND_SYNC);
		break;
	case 6:
		PlaySound(TEXT("m6.wav"),NULL,SND_SYNC);
		break;
	case 7:
		PlaySound(TEXT("m7.wav"),NULL,SND_SYNC);
		break;

	case 8:
		PlaySound(TEXT("m8.wav"),NULL,SND_SYNC);
		break;
	case 9:
		PlaySound(TEXT("m9.wav"),NULL,SND_SYNC);
		break;
	case 10:
		PlaySound(TEXT("m10.wav"),NULL,SND_SYNC);
		break;
	case 11:
		PlaySound(TEXT("m11.wav"),NULL,SND_SYNC);
		break;
	case 12:
		PlaySound(TEXT("m12.wav"),NULL,SND_SYNC);
		break;

	case 13:
		PlaySound(TEXT("m13.wav"),NULL,SND_SYNC);
		break;
	case 14:
		PlaySound(TEXT("m14.wav"),NULL,SND_SYNC);
		break;
	case 15:
		PlaySound(TEXT("m15.wav"),NULL,SND_SYNC);
		break;
}

}




int iftouch(int x,int y,int xr,int yr,int d)
{
//considering 16 cells with d distance



if(x>=xr && y>=yr)
{	cout<<"sound on"; 
	int n=0;
	if(x<xr+d && y<yr+d && n==0)
	{
			cout<<"0";
		play(0);
		
		n=1;
		return 0;
	}
	if(x<xr+2*d && y<yr+d && n==0)
	{
		cout<<"1";
		play(1);
		n=1;
		return 0;
	}
	if(x<xr+3*d && y<yr+d && n==0)
	{
		cout<<"2";
		play(2);
		n=1;
		
		return 0;
	}
	if(x<xr+4*d && y<yr+d && n==0)
	{
		cout<<"3";
		play(3);
		n=1;
		
		return 0;
	}
	if(x<xr+d && y<yr+2*d && n==0)
	{
		cout<<"4";
		play(4);
		n=1;
		return 0;
	}
	if(x<xr+2*d && y<yr+2*d && n==0)
	{
		cout<<"5";
		play(5);
		n=1;
		return 0;
	}
	if(x<xr+3*d && y<yr+2*d && n==0)
	{
		cout<<"6";
		play(6);
		n=1;
		return 0;
	}
	if(x<xr+4*d && y<yr+2*d && n==0)
	{
		cout<<"7";
		play(7);
		n=1;
		return 0;
	}
	if(x<xr+d && y<yr+3*d && n==0)
	{
		cout<<"8";
		play(8);
		n=1;
		return 0;
	}
	if(x<xr+2*d && y<yr+3*d && n==0)
	{
		cout<<"9";
		play(9);
		n=1;
		return 0;
	}
	if(x<xr+3*d && y<yr+3*d && n==0)
	{
		cout<<"10";
		play(10);
		n=1;
		return 0;
	}
	if(x<xr+4*d && y<yr+3*d && n==0)
	{
		cout<<"11";
		play(11);
		n=1;
		return 0;
	}
	if(x<xr+d && y<yr+4*d && n==0)
	{
		cout<<"12";
		play(12);
		n=1;
		return 0;
	}
	if(x<xr+2*d && y<yr+4*d && n==0)
	{
		cout<<"13";
		play(13);
		n=1;
		return 0;
	}
	if(x<xr+3*d && y<yr+4*d && n==0)
	{
		cout<<"14";
		play(14);
		n=1;
		return 0;
	}
	if(x<xr+4*d && y<yr+4*d && n==0)
	{
		cout<<"15";
		play(15);
		n=1;
		return 0;
	}
	
	
}

else
	cout<<"Pixel not in the grid";

	return 0;
}



int main(){
	
	iftouch(3,2,0,0,2);
	return 0;
}
